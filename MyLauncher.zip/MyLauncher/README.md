# MyLauncher — каркас лаунчера (Kotlin + Compose)

Что внутри: экраны входа, версий + кнопка «Играть», друзей/чата/команды по коду, админ-панель для СВОЕГО сервера.

## Как подключить запуск Java Minecraft
1. Форкните PojavLauncher (github.com/PojavLauncherTeam/PojavLauncher), лицензия LGPL-3.0.
2. Добавьте этот UI как новые Activity/экраны, а в `LauncherBridge.launch()` вызовите их JVM-запуск
   (в Pojav это `JMinecraftVersionList` + `LauncherActivity` / `MainActivity`).
3. Вход Microsoft: используйте их готовый MicrosoftAuthenticator.
4. Против лагов: рендер GL4ES/Zink, Xmx 1.5–2 ГБ, Sodium-аналоги.

## Сервер для друзей/чата/голоса
Нужен бэкенд: WebSocket (чат, команды по коду) + WebRTC (голос). `SocialApi` — заглушка под него.

## Админ-панель
Отправляет команды на ваш сервер (RCON): fly, gamemode, tp, vanish. Только для серверов, где вы админ.
