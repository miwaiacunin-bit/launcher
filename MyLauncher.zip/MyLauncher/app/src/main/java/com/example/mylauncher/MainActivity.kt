package com.example.mylauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

@Composable
fun App() {
    var acc by remember { mutableStateOf<Account?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    val a = acc
    if (a == null) { LoginScreen { acc = it }; return }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("Играть", "Друзья", "Админ").forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t) })
            }
        }
    }) { p ->
        Box(Modifier.padding(p).padding(16.dp)) {
            when (tab) { 0 -> PlayScreen(a); 1 -> FriendsScreen(); else -> AdminScreen() }
        }
    }
}

@Composable
fun LoginScreen(onLogin: (Account) -> Unit) {
    var nick by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("MyLauncher", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(nick, { nick = it }, label = { Text("Ник (офлайн)") }, modifier = Modifier.fillMaxWidth())
        Button({ if (nick.isNotBlank()) onLogin(Account(nick, false)) }, Modifier.fillMaxWidth()) { Text("Войти офлайн") }
        OutlinedButton({ /* TODO: Microsoft OAuth */ onLogin(Account("MicrosoftUser", true)) }, Modifier.fillMaxWidth()) { Text("Войти через Microsoft") }
    }
}

@Composable
fun PlayScreen(acc: Account) {
    var selected by remember { mutableStateOf(LauncherBridge.versions.first()) }
    Column {
        Text("Аккаунт: ${acc.name}")
        LazyColumn(Modifier.weight(1f)) {
            items(LauncherBridge.versions) { v ->
                Row(Modifier.fillMaxWidth().padding(4.dp)) {
                    RadioButton(selected == v, { selected = v })
                    Text(v.id, Modifier.weight(1f))
                    if (!v.installed) TextButton({ LauncherBridge.download(v) }) { Text("Скачать") }
                }
            }
        }
        Button({ LauncherBridge.launch(selected, acc) }, Modifier.fillMaxWidth(), enabled = selected.installed) { Text("Играть") }
        OutlinedButton({ LauncherBridge.exit() }, Modifier.fillMaxWidth()) { Text("Выход") }
    }
}

@Composable
fun FriendsScreen() {
    var code by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var team by remember { mutableStateOf<String?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ team = SocialApi.createTeam() }) { Text("Создать команду") }
        team?.let { Text("Код команды: $it") }
        OutlinedTextField(code, { code = it }, label = { Text("Код команды") })
        Button({ SocialApi.joinByCode(code) }) { Text("Войти по коду") }
        OutlinedTextField(msg, { msg = it }, label = { Text("Сообщение другу") })
        Row {
            Button({ SocialApi.sendMessage("friend", msg); msg = "" }) { Text("Отправить") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton({ /* TODO: WebRTC микрофон */ }) { Text("Микрофон") }
        }
    }
}

@Composable
fun AdminScreen() {
    Column {
        Text("Админ-инструменты (ваш сервер)", style = MaterialTheme.typography.titleMedium)
        listOf("Полёт", "Творческий режим", "Невидимость").forEach { name ->
            var on by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(name, Modifier.weight(1f))
                Switch(on, { on = it; AdminApi.setFlag(name, it) })
            }
        }
    }
}
