package com.example.mylauncher

data class Account(val name: String, val microsoft: Boolean)
data class McVersion(val id: String, var installed: Boolean = false)

object LauncherBridge {
    var account: Account? = null
    val versions = mutableStateListOfVersions()

    private fun mutableStateListOfVersions() =
        androidx.compose.runtime.mutableStateListOf(McVersion("1.21.1"), McVersion("1.20.4"), McVersion("1.16.5"), McVersion("1.8.9"))

    fun download(v: McVersion) { /* TODO: скачать client.json + jar + libraries (Mojang manifest) */ v.installed = true }
    fun launch(v: McVersion, acc: Account) { /* TODO: вызвать JVM-запуск PojavLauncher */ }
    fun exit() { android.os.Process.killProcess(android.os.Process.myPid()) }
}

object SocialApi {
    fun createTeam(): String = "ABC123" // TODO: запрос на ваш сервер
    fun joinByCode(code: String) {}
    fun sendMessage(friend: String, text: String) {}
}

object AdminApi {
    // TODO: RCON на ваш сервер, например "gamemode creative <ник>"
    fun setFlag(name: String, on: Boolean) {}
}
