const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path'), fs = require('fs'), crypto = require('crypto');
const { Client, Authenticator } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const ROOT = path.join(app.getPath('userData'), 'game');
const CFG = path.join(app.getPath('userData'), 'config.json');
// Ключ администратора хранится только как хеш и проверяется здесь, не в интерфейсе
const ADMIN_HASH = crypto.createHash('sha256').update('2580').digest('hex');
let win, auth = null, mode = null;

const cfg = () => { try { return JSON.parse(fs.readFileSync(CFG)); } catch { return { ver: '1.21.1', auto: true }; } };
const send = (ch, v) => win && win.webContents.send(ch, v);

async function download(url, dest, label, base, span) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const r = await fetch(url); if (!r.ok) throw new Error(label + ': HTTP ' + r.status);
  const total = +r.headers.get('content-length') || 0; let got = 0;
  const out = fs.createWriteStream(dest);
  for await (const chunk of r.body) { out.write(chunk); got += chunk.length; if (total) send('progress', base + span * got / total); }
  await new Promise(res => out.end(res));
}

// Установка: манифест версий Mojang -> json и client.jar нужной версии.
// Библиотеки и ресурсы докачает minecraft-launcher-core при первом запуске.
ipcMain.handle('install', async () => {
  const { ver, auto } = cfg();
  send('log', 'Получаю список версий'); send('progress', 2);
  const man = await (await fetch('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json')).json();
  const v = man.versions.find(x => x.id === ver); if (!v) throw new Error('Версия не найдена: ' + ver);
  const meta = await (await fetch(v.url)).json();
  const dir = path.join(ROOT, 'versions', ver);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, ver + '.json'), JSON.stringify(meta));
  if (auto) { send('log', 'Скачиваю игру ' + ver); await download(meta.downloads.client.url, path.join(dir, ver + '.jar'), 'client', 5, 95); }
  send('progress', 100); send('log', 'Готово: ' + ver);
  return true;
});

ipcMain.handle('login-offline', (_e, name) => {
  if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error('Ник: 3–16 символов, латиница, цифры, _');
  auth = Authenticator.getAuth(name); mode = 'offline'; return { name, mode };
});

ipcMain.handle('login-ms', async () => {
  const res = await new Auth('select_account').launch('electron');
  const mc = await res.getMinecraft();
  auth = mc.mclc(); mode = 'ms';
  return { name: mc.profile.name, mode };
});

ipcMain.handle('launch', async (_e, mods) => {
  if (!auth) throw new Error('Сначала войди в аккаунт');
  const { ver } = cfg();
  const opts = {
    authorization: auth, root: ROOT, javaPath: 'java',
    version: { number: ver, type: 'release' },
    memory: { max: '4G', min: '1G' },
  };
  // TODO моды (только mode === 'ms'): скачать jar в ROOT/mods (например через Modrinth API).
  //  Forge: opts.forge = путь к forge-installer.jar
  //  Fabric: opts.version.custom = 'fabric-loader-<...>-' + ver (после установки loader)
  //  OptiFine: положить jar в ROOT/mods (нужен Forge или Fabric + OptiFabric)
  const l = new Client();
  l.on('debug', m => send('log', m)); l.on('progress', p => send('progress', p.total ? 100 * p.task / p.total : 0));
  l.on('close', c => send('log', 'Игра закрыта, код ' + c));
  await l.launch(opts); return true;
});

ipcMain.handle('admin-check', (_e, k) => crypto.createHash('sha256').update(String(k)).digest('hex') === ADMIN_HASH);
ipcMain.handle('cfg-get', () => cfg());
ipcMain.handle('cfg-set', (_e, c) => { fs.writeFileSync(CFG, JSON.stringify({ ...cfg(), ...c })); return true; });

app.whenReady().then(() => {
  win = new BrowserWindow({ width: 480, height: 760, webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true } });
  win.setMenuBarVisibility(false);
  win.loadFile('renderer/index.html');
});
app.on('window-all-closed', () => app.quit());
