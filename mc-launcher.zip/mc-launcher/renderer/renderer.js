const $ = id => document.getElementById(id);
const state = { mode: null, mods: {}, ver: '1.21.1' };
const MODS = [['OptiFine', 'графика и FPS'], ['Forge', 'загрузчик модов'], ['Fabric', 'лёгкий загрузчик']];
const show = id => ['install', 'login', 'main', 'admin'].forEach(s => $('s-' + s).classList.toggle('hide', s !== id));
const fail = (el, e) => { el.textContent = String(e.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''); };

api.onLog(m => { $('log').style.whiteSpace = 'pre-line'; $('log').textContent = m; $('runmsg').textContent = m; });
api.onProgress(p => { $('bar').style.width = Math.min(100, p) + '%'; });

api.getConfig().then(c => { state.ver = c.ver; $('ver').textContent = c.ver; $('vsel').value = c.ver; $('auto').textContent = c.auto ? 'Вкл' : 'Выкл'; });

$('go').onclick = async () => {
  $('go').disabled = true;
  try { await api.install(); setTimeout(() => show('login'), 700); }
  catch (e) { fail($('log'), e); $('go').disabled = false; }
};

$('offline').onclick = () => $('offbox').classList.toggle('hide');
$('offgo').onclick = async () => {
  try { const r = await api.loginOffline($('nick').value.trim()); enter(r); } catch (e) { fail($('loginerr'), e); }
};
$('ms').onclick = async () => {
  $('loginerr').textContent = 'Открываю вход Microsoft…';
  try { const r = await api.loginMicrosoft(); $('loginerr').textContent = ''; enter(r); } catch (e) { fail($('loginerr'), e); }
};

function enter(r) {
  state.mode = r.mode;
  $('hello').textContent = 'Привет, ' + r.name;
  $('mode').textContent = r.mode === 'ms' ? 'Вход через Microsoft' : 'Оффлайн-режим';
  $('modcard').style.opacity = r.mode === 'ms' ? 1 : .5;
  $('add').disabled = r.mode !== 'ms';
  $('msnote').classList.toggle('hide', r.mode === 'ms');
  renderMods(); show('main');
}

function renderMods() {
  $('mods').innerHTML = MODS.map(([n, d]) => `<div class="row"><div>${n}<small>${d}</small></div><button class="alt" data-m="${n}" ${state.mode !== 'ms' ? 'disabled' : ''}>${state.mods[n] ? 'Убрать' : 'Добавить'}</button></div>`).join('');
  $('mods').querySelectorAll('button').forEach(b => b.onclick = () => { state.mods[b.dataset.m] = !state.mods[b.dataset.m]; renderMods(); });
}
$('add').onclick = () => { const n = MODS.find(([m]) => !state.mods[m]); if (n) { state.mods[n[0]] = true; renderMods(); } };

$('pc').onclick = async () => {
  $('runmsg').textContent = 'Запускаю…';
  try { await api.launch(Object.keys(state.mods).filter(k => state.mods[k])); } catch (e) { fail($('runmsg'), e); }
};
$('ph').onclick = () => { $('runmsg').textContent = 'Телефон: нужна отдельная Android-версия (см. README).'; };

$('adm').onclick = () => { $('key').value = ''; $('keyerr').textContent = ''; $('akey').classList.remove('hide'); $('apanel').classList.add('hide'); show('admin'); };
$('keygo').onclick = async () => {
  if (await api.adminCheck($('key').value)) { $('akey').classList.add('hide'); $('apanel').classList.remove('hide'); }
  else $('keyerr').textContent = 'Неверный ключ';
};
$('vsel').onchange = e => { state.ver = e.target.value || '1.21.1'; api.setConfig({ ver: state.ver }); $('ver').textContent = state.ver; };
$('auto').onclick = async () => { const on = $('auto').textContent !== 'Вкл'; $('auto').textContent = on ? 'Вкл' : 'Выкл'; api.setConfig({ auto: on }); };
$('reset').onclick = () => { state.mode = null; state.mods = {}; $('go').disabled = false; $('bar').style.width = '0'; $('log').textContent = 'Готов к установке.'; show('install'); };
$('back').onclick = () => show(state.mode ? 'main' : 'install');
