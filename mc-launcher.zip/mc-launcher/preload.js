const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  install: () => ipcRenderer.invoke('install'),
  loginOffline: n => ipcRenderer.invoke('login-offline', n),
  loginMicrosoft: () => ipcRenderer.invoke('login-ms'),
  launch: mods => ipcRenderer.invoke('launch', mods),
  adminCheck: k => ipcRenderer.invoke('admin-check', k),
  getConfig: () => ipcRenderer.invoke('cfg-get'),
  setConfig: c => ipcRenderer.invoke('cfg-set', c),
  onLog: cb => ipcRenderer.on('log', (_e, m) => cb(m)),
  onProgress: cb => ipcRenderer.on('progress', (_e, p) => cb(p)),
});
